﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace CarDekho.Models
{
    public class CarContext : DbContext
    {
        public CarContext(DbContextOptions<CarContext> options) : base(options)
        {
        }
        public DbSet<CarModels> Cars { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<CarModels>().HasData(new CarModels { IdCar = 1, Brand = "Fruit pies" });

            modelBuilder.Entity<CarModels>().HasData(new CarModels
            {
                IdCar = 1,
                Brand = "Polo",
                Model="New"
            });
        }
    }    
}
