﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Drive.Migrations
{
    public partial class newdb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CategoryNewCar",
                columns: table => new
                {
                    Price = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CategoryNewCar", x => x.Price);
                });

            migrationBuilder.CreateTable(
                name: "CategoryUsedCar",
                columns: table => new
                {
                    CategoryUsedCarId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CategoryUsedCar", x => x.CategoryUsedCarId);
                });

            migrationBuilder.CreateTable(
                name: "Feedback",
                columns: table => new
                {
                    feed = table.Column<string>(nullable: false),
                    naam = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Feedback", x => x.feed);
                });

            migrationBuilder.CreateTable(
                name: "NewCar",
                columns: table => new
                {
                    NewCarid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Model = table.Column<int>(nullable: false),
                    Engine = table.Column<int>(nullable: false),
                    seat = table.Column<int>(nullable: false),
                    mileage = table.Column<int>(nullable: false),
                    color = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NewCar", x => x.NewCarid);
                });

            migrationBuilder.CreateTable(
                name: "UsedCar",
                columns: table => new
                {
                    UsedCarid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Year = table.Column<int>(nullable: false),
                    Model = table.Column<string>(nullable: true),
                    Engine = table.Column<int>(nullable: false),
                    seat = table.Column<int>(nullable: false),
                    MeterReading = table.Column<int>(nullable: false),
                    color = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsedCar", x => x.UsedCarid);
                });

            migrationBuilder.CreateTable(
                name: "User",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    DOB = table.Column<string>(nullable: true),
                    Occupation = table.Column<string>(nullable: true),
                    phone = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.id);
                });

            migrationBuilder.InsertData(
                table: "CategoryNewCar",
                columns: new[] { "Price", "Brand" },
                values: new object[,]
                {
                    { 300000, "Audi" },
                    { 1500000, "MG" }
                });

            migrationBuilder.InsertData(
                table: "CategoryUsedCar",
                columns: new[] { "CategoryUsedCarId", "Brand" },
                values: new object[,]
                {
                    { 1, "Hyundai" },
                    { 2, "Volkswagen" },
                    { 3, "Audi" }
                });

            migrationBuilder.InsertData(
                table: "Feedback",
                columns: new[] { "feed", "naam" },
                values: new object[] { "Please help us improve more", "Hey" });

            migrationBuilder.InsertData(
                table: "NewCar",
                columns: new[] { "NewCarid", "Engine", "Model", "color", "mileage", "seat" },
                values: new object[,]
                {
                    { 1, 5858, 858, "Blue", 546, 4 },
                    { 2, 5858, 858, "Blue", 546, 4 },
                    { 3, 8569, 123, "Red", 546, 6 },
                    { 4, 7898, 0, "Black", 858, 5 }
                });

            migrationBuilder.InsertData(
                table: "UsedCar",
                columns: new[] { "UsedCarid", "Engine", "MeterReading", "Model", "Year", "color", "seat" },
                values: new object[,]
                {
                    { 1, 5858, 98562, "hyundai", 0, "Blue", 4 },
                    { 2, 9632, 47576, "hyundai", 0, "Red", 4 },
                    { 3, 1498, 1482, "Volkswagen", 0, "BLack", 6 }
                });

            migrationBuilder.InsertData(
                table: "User",
                columns: new[] { "id", "Address", "DOB", "Email", "Gender", "Occupation", "Password", "Status", "name", "phone" },
                values: new object[,]
                {
                    { 1, "12/24", null, "diksha@gmail.com", "Female", "student", null, null, "Diksha", null },
                    { 2, "45/5", null, "xceed@gmail.com", "Female", "Employee", null, null, "Xceedance", null },
                    { 3, "13/85", null, "xc@gmail.com", "male", "Business", null, null, "Xceed", null }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CategoryNewCar");

            migrationBuilder.DropTable(
                name: "CategoryUsedCar");

            migrationBuilder.DropTable(
                name: "Feedback");

            migrationBuilder.DropTable(
                name: "NewCar");

            migrationBuilder.DropTable(
                name: "UsedCar");

            migrationBuilder.DropTable(
                name: "User");
        }
    }
}
