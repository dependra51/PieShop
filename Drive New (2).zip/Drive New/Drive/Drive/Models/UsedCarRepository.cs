﻿using Drive.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Drive.Controllers
{
    public class UsedCarRepository :IUsedCarRepository
    {
        private readonly DataDbContext _dataDbContext;

        public UsedCarRepository(DataDbContext dataDbContext)
        {
            _dataDbContext = dataDbContext;
        }

        public IEnumerable<UsedCar> AllCars
        {
            get
            {
                return _dataDbContext.UsedCar.ToList();
            }


        }
    }
}
