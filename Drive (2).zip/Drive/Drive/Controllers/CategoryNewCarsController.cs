﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Drive.Models;

namespace Drive.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryNewCarsController : ControllerBase
    {
        private readonly DataDbContext _context;

        public CategoryNewCarsController(DataDbContext context)
        {
            _context = context;
        }

        // GET: api/CategoryNewCars
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoryNewCar>>> GetCategoryNewCar()
        {
            return await _context.CategoryNewCar.ToListAsync();
        }

        // GET: api/CategoryNewCars/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CategoryNewCar>> GetCategoryNewCar(int id)
        {
            var categoryNewCar = await _context.CategoryNewCar.FindAsync(id);

            if (categoryNewCar == null)
            {
                return NotFound();
            }

            return categoryNewCar;
        }

        // PUT: api/CategoryNewCars/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategoryNewCar(int id, CategoryNewCar categoryNewCar)
        {
            if (id != categoryNewCar.Price)
            {
                return BadRequest();
            }

            _context.Entry(categoryNewCar).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CategoryNewCarExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CategoryNewCars
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<CategoryNewCar>> PostCategoryNewCar(CategoryNewCar categoryNewCar)
        {
            _context.CategoryNewCar.Add(categoryNewCar);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCategoryNewCar", new { id = categoryNewCar.Price }, categoryNewCar);
        }

        // DELETE: api/CategoryNewCars/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CategoryNewCar>> DeleteCategoryNewCar(int id)
        {
            var categoryNewCar = await _context.CategoryNewCar.FindAsync(id);
            if (categoryNewCar == null)
            {
                return NotFound();
            }

            _context.CategoryNewCar.Remove(categoryNewCar);
            await _context.SaveChangesAsync();

            return categoryNewCar;
        }

        private bool CategoryNewCarExists(int id)
        {
            return _context.CategoryNewCar.Any(e => e.Price == id);
        }
    }
}
